package com.company;

public class Main {

    public static void main(String[] args) {
      coche micoche = new coche();
        micoche.addpuertas();
        System.out.println(micoche.puertas);

        int resultado;
    resultado = suma(23,47, 84);
        System.out.println(resultado);
    }

   public static int suma(int valorA, int valorB, int valorC)
   {
    return valorA + valorB + valorC;
   }
}

class coche{
    public int puertas = 5;

    public void addpuertas(){
        this.puertas++;
    }
}